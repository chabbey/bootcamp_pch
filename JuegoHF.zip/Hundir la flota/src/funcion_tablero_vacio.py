import numpy as np

def grid_blank(x, y):
    grid = np.full((x, y), ' ')

    return grid