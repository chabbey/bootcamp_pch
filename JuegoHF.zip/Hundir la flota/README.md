# Bootcamp Hundir la flota, Ángel y Pablo

## Proyecto Hundir la Flota

>Autores: 
>>Pablo Chabbey y Ángel Pizarro.
>
>Librerías: 
>>La librería utilizada en el proyecto es Numpy.
>
>Recursos utilizados: 
>>Visual Code y Pycharm para desarrollar y ejecutar el código. 
>
>Descripción del proyecto:
>>Hundir la flota se compone de una serie de funciones. 
>>>Estas funciones son:
>>>>Función tablero: se crean dos tableros y se colocan de manera aleatoria los barcos.
>>>>
>>>>Función tablero vacío: se crea un tablero donde el jugador puede ver los disparos que va realizando.
>>>>
>>>>Función disparo manual: el jugador introduce las coordenadas donde desea realizar su disparo.
>>>>
>>>>Función disparo aleatorio: el bot introduce unas coordenadas de manera aleatoria y ejecuta el disparo.
>>
>>Todas las funciones se ejecutan en un script de python donde, a través de un bucle while, se realizan los disparos por ambas
>>partes hasta que uno de los usuarios (jugador o bot) se queda sin barcos y, por lo tanto, termina la partida.